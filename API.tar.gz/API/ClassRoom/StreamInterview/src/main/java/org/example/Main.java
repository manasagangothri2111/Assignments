package org.example;

import java.util.ArrayList;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        // Press Alt+Enter with your caret at the highlighted text to see how
        // IntelliJ IDEA suggests fixing it.
        System.out.printf("Hello and welcome!");

        ArrayList<Employee> emp = new ArrayList<Employee>();
        emp.add(new Employee("Manasa","asas",12));
        emp.add(new Employee("dsdsd","asasas",23));
        emp.add(new Employee("qsdwq","asas",34));
        emp.add(new Employee("asas","asas",2));
        emp.add(new Employee("sdas","asas",45));
        emp.add(new Employee("sdasas","asas",67));
        emp.add(new Employee("qseda","asas",45));
    }
}