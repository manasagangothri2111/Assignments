package com.chefapp.identityservice.entity;

public enum Role {
    USER,
    ADMIN
}
