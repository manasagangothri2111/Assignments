package com.cts;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/customers")
@AllArgsConstructor
@Slf4j
public class CustomerController {

	private CustomerService service;

	@PostMapping
	public void registerCustomer(@RequestBody CustomerRegistrationRequest request) {
		log.info("New Customer Registration {}", request);
		service.registerCustomer(request);
	}
}
