package com.cts;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CustomerService {

	private CustomerRepository repository;

	@Lazy
	private RestTemplate restTemplate;
	
	public void registerCustomer(CustomerRegistrationRequest request) {
		Customer customer = Customer.builder().firstName(request.firstName()).lastName(request.lastName())
				.email(request.email()).build();
		repository.save(customer);
		
		FraudCheckResponse fraudCheckResponse = restTemplate
			.getForObject("http://FRAUD-SERVICE/api/v1/fraud-check/{customerId}", FraudCheckResponse.class,customer.getId());
		
		if(fraudCheckResponse.isFraudster())
			throw new IllegalStateException("fraudster");
		
	}
	

}
