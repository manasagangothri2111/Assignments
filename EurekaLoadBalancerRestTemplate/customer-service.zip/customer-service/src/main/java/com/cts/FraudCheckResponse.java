package com.cts;

public record FraudCheckResponse(Boolean isFraudster) {

}
