package com.cts;

public class FraudClient {

}
