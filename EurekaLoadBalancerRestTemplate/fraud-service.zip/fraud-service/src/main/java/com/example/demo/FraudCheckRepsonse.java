package com.example.demo;

public record FraudCheckRepsonse(Boolean isFraudster) {

}
