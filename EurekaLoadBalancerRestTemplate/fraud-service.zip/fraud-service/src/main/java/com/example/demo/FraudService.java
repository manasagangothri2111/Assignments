package com.example.demo;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class FraudService {

	private FraudCheckHistoryRepository repository;

	public boolean isFraudulentCustomer(Integer customerId) {
		repository
		.save(FraudCheckHistory.builder()
				.customerId(customerId).isFraudster(false)
				.createdAt(LocalDateTime.now()).build());
	
		return false;
	}

}
