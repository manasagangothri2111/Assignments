package com.techutube.userregistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
